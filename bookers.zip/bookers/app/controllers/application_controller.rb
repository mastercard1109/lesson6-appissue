class ApplicationController < ActionController::Base

  def index
  end

  private


end
